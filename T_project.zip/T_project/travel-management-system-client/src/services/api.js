
import axios from 'axios';

const API_URL = 'http://localhost:3000'; // Update with your server URL

export const getUsers = () => axios.get(`${API_URL}/users`);
export const createUser = (data) => axios.post(`${API_URL}/users`, data);

export const getPackages = () => axios.get(`${API_URL}/packages`);
export const createPackage = (data) => axios.post(`${API_URL}/packages`, data);

export const getReviews = () => axios.get(`${API_URL}/reviews`);
export const createReview = (data) => axios.post(`${API_URL}/reviews`, data);

export const getBookings = () => axios.get(`${API_URL}/bookings`);
export const createBooking = (data) => axios.post(`${API_URL}/bookings`, data);

export const getPayments = () => axios.get(`${API_URL}/payments`);
export const createPayment = (data) => axios.post(`${API_URL}/payments`, data);
