

import React from 'react';
import UserForm from './components/UserForm';
import PackageList from './components/PackageList';
import ReviewForm from './components/ReviewForm';
import BookingForm from './components/BookingForm';
import PaymentForm from './components/PaymentForm';
import './App.css';

const App = () => {
    return (
        <div className="App">
            <header className="App-header">
                <h1>Travel Management System</h1>
            </header>
            <main>
                <section>
                    <UserForm />
                </section>
                <section>
                    <PackageList />
                </section>
                <section>
                    <ReviewForm />
                </section>
                <section>
                    <BookingForm />
                </section>
                <section>
                    <PaymentForm />
                </section>
            </main>
        </div>
    );
};

export default App;

