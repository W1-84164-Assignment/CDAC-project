
import React, { useState } from 'react';
import { createReview } from '../services/api';

const ReviewForm = () => {
    const [packageID, setPackageID] = useState('');
    const [userID, setUserID] = useState('');
    const [rating, setRating] = useState('');
    const [comment, setComment] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await createReview({ PackageID: packageID, UserID: userID, Rating: rating, Comment: comment });
            alert('Review created successfully');
        } catch (error) {
            console.error(error);
            alert('Error creating review');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Create Review</h2>
            <div>
                <label>Package ID</label>
                <input type="number" value={packageID} onChange={(e) => setPackageID(e.target.value)} />
            </div>
            <div>
                <label>User ID</label>
                <input type="number" value={userID} onChange={(e) => setUserID(e.target.value)} />
            </div>
            <div>
                <label>Rating</label>
                <input type="number" value={rating} onChange={(e) => setRating(e.target.value)} min="1" max="5" />
            </div>
            <div>
                <label>Comment</label>
                <textarea value={comment} onChange={(e) => setComment(e.target.value)}></textarea>
            </div>
            <button type="submit">Create Review</button>
        </form>
    );
};

export default ReviewForm;
