
import React, { useState } from 'react';
import { createUser } from '../services/api';

const UserForm = () => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('User');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await createUser({ Username: username, Email: email, PasswordHash: password, Role: role });
            alert('User created successfully');
        } catch (error) {
            console.error(error);
            alert('Error creating user');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Create User</h2>
            <div>
                <label>Username</label>
                <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
            </div>
            <div>
                <label>Email</label>
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div>
                <label>Password</label>
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            <div>
                <label>Role</label>
                <select value={role} onChange={(e) => setRole(e.target.value)}>
                    <option value="User">User</option>
                    <option value="Admin">Admin</option>
                </select>
            </div>
            <button type="submit">Create User</button>
            <a href="https://www.google.com" target="_blank"> ssave</a>
        </form>
    );
};

export default UserForm;
