
import React, { useEffect, useState } from 'react';
import { getPackages } from '../services/api';

const PackageList = () => {
    const [packages, setPackages] = useState([]);

    useEffect(() => {
        const fetchPackages = async () => {
            try {
                const response = await getPackages();
                setPackages(response.data);
            } catch (error) {
                console.error(error);
            }
        };
        fetchPackages();
    }, []);

    return (
        <div>
            <h2>Packages</h2>
            <ul>
                {packages.map(pkg => (
                    <li key={pkg.PackageID}>
                        <h3>{pkg.Title}</h3>
                        <p>{pkg.Description}</p>
                        <p>Destination: {pkg.Destination}</p>
                        <p>Duration: {pkg.Duration} days</p>
                        <p>Price: ${pkg.Price}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default PackageList;
