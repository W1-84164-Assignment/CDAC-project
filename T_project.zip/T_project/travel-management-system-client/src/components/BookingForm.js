

import React, { useState } from 'react';
import { createBooking } from '../services/api';

const BookingForm = () => {
    const [userID, setUserID] = useState('');
    const [packageID, setPackageID] = useState('');
    const [bookingDate, setBookingDate] = useState('');
    const [numberOfPeople, setNumberOfPeople] = useState('');
    const [totalPrice, setTotalPrice] = useState('');
    const [paymentStatus, setPaymentStatus] = useState('Pending');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await createBooking({
                UserID: userID,
                PackageID: packageID,
                BookingDate: bookingDate,
                NumberOfPeople: numberOfPeople,
                TotalPrice: totalPrice,
                PaymentStatus: paymentStatus
            });
            alert('Booking created successfully');
        } catch (error) {
            console.error(error);
            alert('Error creating booking');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Create Booking</h2>
            <div>
                <label>User ID</label>
                <input type="number" value={userID} onChange={(e) => setUserID(e.target.value)} />
            </div>
            <div>
                <label>Package ID</label>
                <input type="number" value={packageID} onChange={(e) => setPackageID(e.target.value)} />
            </div>
            <div>
                <label>Booking Date</label>
                <input type="date" value={bookingDate} onChange={(e) => setBookingDate(e.target.value)} />
            </div>
            <div>
                <label>Number of People</label>
                <input type="number" value={numberOfPeople} onChange={(e) => setNumberOfPeople(e.target.value)} />
            </div>
            <div>
                <label>Total Price</label>
                <input type="number" value={totalPrice} onChange={(e) => setTotalPrice(e.target.value)} />
            </div>
            <div>
                <label>Payment Status</label>
                <select value={paymentStatus} onChange={(e) => setPaymentStatus(e.target.value)}>
                    <option value="Pending">Pending</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
            </div>
            <button type="submit">Create Booking</button>
        </form>
    );
};

export default BookingForm;
