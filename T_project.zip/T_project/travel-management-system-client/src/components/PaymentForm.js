

import React, { useState } from 'react';
import { createPayment } from '../services/api';

const PaymentForm = () => {
    const [bookingID, setBookingID] = useState('');
    const [amount, setAmount] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('CreditCard');
    const [transactionID, setTransactionID] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await createPayment({
                BookingID: bookingID,
                Amount: amount,
                PaymentMethod: paymentMethod,
                TransactionID: transactionID
            });
            alert('Payment created successfully');
        } catch (error) {
            console.error(error);
            alert('Error creating payment');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Create Payment</h2>
            <div>
                <label>Booking ID</label>
                <input type="number" value={bookingID} onChange={(e) => setBookingID(e.target.value)} />
            </div>
            <div>
                <label>Amount</label>
                <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
            </div>
            <div>
                <label>Payment Method</label>
                <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                    <option value="CreditCard">CreditCard</option>
                    <option value="DebitCard">DebitCard</option>
                    <option value="PayPal">PayPal</option>
                    <option value="BankTransfer">BankTransfer</option>
                </select>
            </div>
            <div>
                <label>Transaction ID</label>
                <input type="text" value={transactionID} onChange={(e) => setTransactionID(e.target.value)} />
            </div>
            <button type="submit">Create Payment</button>
        </form>
    );
};

export default PaymentForm;
