

module.exports = {
    database: 'projectdb',
    username: 'root',
    password: 'manager',
    host: 'localhost',
    dialect: 'mysql'
};
