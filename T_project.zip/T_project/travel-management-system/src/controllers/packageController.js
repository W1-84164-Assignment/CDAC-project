

const Package = require('../models/Package');

exports.getAllPackages = async (req, res) => {
    try {
        const packages = await Package.findAll();
        res.json(packages);
    } catch (error) {
        res.status(500).send(error.message);
    }
};

exports.createPackage = async (req, res) => {
    try {
        const package = await Package.create(req.body);
        res.status(201).json(package);
    } catch (error) {
        res.status(500).send(error.message);
    }
};
