

// src/models/Package.js
const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');

const Package = sequelize.define('Package', {
    PackageID: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    Title: { type: DataTypes.STRING, allowNull: false },
    Description: { type: DataTypes.TEXT },
    Destination: { type: DataTypes.STRING },
    Duration: { type: DataTypes.INTEGER },
    Price: { type: DataTypes.DECIMAL(10, 2) },
    CreatedAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

module.exports = Package;
