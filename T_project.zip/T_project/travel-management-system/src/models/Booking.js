


const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');

const Booking = sequelize.define('Booking', {
    BookingID: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    UserID: { type: DataTypes.INTEGER, allowNull: false },
    PackageID: { type: DataTypes.INTEGER, allowNull: false },
    BookingDate: { type: DataTypes.DATE, allowNull: false },
    NumberOfPeople: { type: DataTypes.INTEGER, allowNull: false },
    TotalPrice: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
    PaymentStatus: { type: DataTypes.ENUM('Pending', 'Completed', 'Cancelled'), defaultValue: 'Pending' },
    CreatedAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

Booking.associate = (models) => {
    Booking.belongsTo(models.User, { foreignKey: 'UserID' });
    Booking.belongsTo(models.Package, { foreignKey: 'PackageID' });
};

module.exports = Booking;
