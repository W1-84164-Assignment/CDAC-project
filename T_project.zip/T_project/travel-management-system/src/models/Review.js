

const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');

const Review = sequelize.define('Review', {
    ReviewID: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    PackageID: { type: DataTypes.INTEGER, allowNull: false },
    UserID: { type: DataTypes.INTEGER, allowNull: false },
    Rating: { type: DataTypes.INTEGER, allowNull: false, validate: { min: 1, max: 5 } },
    Comment: { type: DataTypes.TEXT },
    CreatedAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

Review.associate = (models) => {
    Review.belongsTo(models.User, { foreignKey: 'UserID' });
    Review.belongsTo(models.Package, { foreignKey: 'PackageID' });
};

module.exports = Review;
