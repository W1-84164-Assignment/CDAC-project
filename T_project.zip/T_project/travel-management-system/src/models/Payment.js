


const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');

const Payment = sequelize.define('Payment', {
    PaymentID: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    BookingID: { type: DataTypes.INTEGER, allowNull: false },
    PaymentDate: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
    Amount: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
    PaymentMethod: { type: DataTypes.ENUM('CreditCard', 'DebitCard', 'PayPal', 'BankTransfer') },
    TransactionID: { type: DataTypes.STRING }
});

Payment.associate = (models) => {
    Payment.belongsTo(models.Booking, { foreignKey: 'BookingID' });
};

module.exports = Payment;
