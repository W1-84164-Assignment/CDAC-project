

const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');

const PackageDetail = sequelize.define('PackageDetail', {
    DetailID: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    PackageID: { type: DataTypes.INTEGER, allowNull: false },
    Day: { type: DataTypes.INTEGER, allowNull: false },
    Itinerary: { type: DataTypes.TEXT },
    Inclusion: { type: DataTypes.TEXT }
});

PackageDetail.associate = (models) => {
    PackageDetail.belongsTo(models.Package, { foreignKey: 'PackageID' });
};

module.exports = PackageDetail;
