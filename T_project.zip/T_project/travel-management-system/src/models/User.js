

// src/models/User.js
const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');

const User = sequelize.define('User', {
    UserID: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    Username: { type: DataTypes.STRING, unique: true, allowNull: false },
    Email: { type: DataTypes.STRING, unique: true, allowNull: false },
    PasswordHash: { type: DataTypes.STRING, allowNull: false },
    Role: { type: DataTypes.ENUM('Admin', 'User'), defaultValue: 'User' },
    CreatedAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

module.exports = User;
